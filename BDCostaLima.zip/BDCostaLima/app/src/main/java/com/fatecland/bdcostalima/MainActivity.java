package com.fatecland.bdcostalima;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private viewHolder mviewHolder = new viewHolder();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mviewHolder.lista = findViewById(R.id.list_main_item);
        this.mviewHolder.dao = new AlunoDAO(this);

        this.mviewHolder.alunos = this.mviewHolder.dao.obterTodos();
        this.mviewHolder.alunosFiltrados.addAll(this.mviewHolder.alunos);

       // ArrayAdapter<Aluno> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
       //         this.mviewHolder.alunosFiltrados);
        AlunoAdapt adapter = new AlunoAdapt(this, mviewHolder.alunosFiltrados);

        this.mviewHolder.lista.setAdapter(adapter);

        registerForContextMenu(this.mviewHolder.lista);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater i = getMenuInflater();
        i.inflate(R.menu.menu_principal, menu);

        SearchView sv = (SearchView) menu.findItem(R.id.app_bar_search).getActionView();
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                procuraAluno(s);
                return false;
            }
        });

        return true;
    }
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu,v,menuInfo);
        MenuInflater i = getMenuInflater();
        i.inflate(R.menu.menu_contexto, menu);
    }

    public void procuraAluno(String nome){
        this.mviewHolder.alunosFiltrados.clear();
        for(Aluno a : this.mviewHolder.alunos){
            if(a.getNome().toLowerCase().contains(nome.toLowerCase())){
                this.mviewHolder.alunosFiltrados.add(a);

            }
        }
        this.mviewHolder.lista.invalidateViews();
    }

    public void btn_menuP_Cadastro(MenuItem item){
        Intent it =new Intent(this, AlteracaoActivity.class);
        startActivity(it);
    }

    public void excluir (MenuItem item){
        final AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        final Aluno Exclusao = this.mviewHolder.alunosFiltrados.get(menuInfo.position);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Atenção")
                .setMessage("Realmente deseja excluir o aluoo?")
                .setNegativeButton("Não", null)
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        mviewHolder.alunosFiltrados.remove(Exclusao);
                        mviewHolder.alunos.remove(Exclusao);
                        mviewHolder.dao.excluir(Exclusao);
                        mviewHolder.lista.invalidateViews();
                    }
                }).create();
        dialog.show();
    }

    public void att(MenuItem item){
        final AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        final Aluno Atualização = this.mviewHolder.alunosFiltrados.get(menuInfo.position);
        Intent i = new Intent(this, AlteracaoActivity.class);
        i.putExtra("aluno", Atualização);
        startActivity(i);
    }

    @Override
    public void onResume(){
        super.onResume();
        this.mviewHolder.alunos = this.mviewHolder.dao.obterTodos();
        this.mviewHolder.alunosFiltrados.clear();
        this.mviewHolder.alunosFiltrados.addAll(this.mviewHolder.alunos);
        this.mviewHolder.lista.invalidateViews();
    }

    private static class viewHolder{
        ListView lista;
        AlunoDAO dao;

        List<Aluno> alunos;
        List<Aluno> alunosFiltrados = new ArrayList<>();

    }
}