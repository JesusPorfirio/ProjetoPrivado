package com.fatecland.bdcostalima;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.EditText;

public class AlteracaoActivity extends AppCompatActivity {

    private viewHolder mviewHolder = new viewHolder();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alteracao);

        this.mviewHolder.edtNome = findViewById(R.id.edt_alter_Nome);
        this.mviewHolder.edtTelefone = findViewById(R.id.edt_alter_fone);
        this.mviewHolder.edtCpf = findViewById(R.id.edt_alter_Cpf);

        this.mviewHolder.dao = new AlunoDAO(this);

        Intent i = getIntent();

        if(i.hasExtra("aluno")){
            this.mviewHolder.aluno = (Aluno) i.getSerializableExtra("aluno");

            mviewHolder.edtNome.setText(mviewHolder.aluno.getNome());
            mviewHolder.edtCpf.setText(mviewHolder.aluno.getCpf());
            mviewHolder.edtTelefone.setText(mviewHolder.aluno.getTelefone());

        }
    }


    public void bnt_alterSave (View view){

        if(mviewHolder.aluno == null){

            mviewHolder.aluno = new Aluno();
            mviewHolder.aluno.setNome(this.mviewHolder.edtNome.getText().toString());
            mviewHolder.aluno.setCpf(this.mviewHolder.edtCpf.getText().toString());
            mviewHolder.aluno.setTelefone(this.mviewHolder.edtTelefone.getText().toString());
            this.mviewHolder.dao.inserir(mviewHolder.aluno);
        }
        else{
            mviewHolder.aluno.setNome(this.mviewHolder.edtNome.getText().toString());
            mviewHolder.aluno.setCpf(this.mviewHolder.edtCpf.getText().toString());
            mviewHolder.aluno.setTelefone(this.mviewHolder.edtTelefone.getText().toString());
            mviewHolder.dao.atualizar(mviewHolder.aluno);
        }
    }


    private static class viewHolder{
        EditText edtNome, edtCpf, edtTelefone;
        private AlunoDAO dao;
        Aluno aluno = null;
    }
}